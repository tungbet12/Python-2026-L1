import pandas as pd

# Load the dataset[cite: 2]
df_students = pd.read_csv('students.csv')

# Display first five rows[cite: 2]
print("First 5 rows:")
print(df_students.head())

# Find number of rows and columns[cite: 2]
rows, cols = df_students.shape
print(f"\nDimensions: {rows} rows, {cols} columns")

# Select name and GPA[cite: 2]
name_and_gpa = df_students[['name', 'GPA']]
print("\nName and GPA:")
print(name_and_gpa.head())

# Find students with GPA >= 3.5[cite: 2]
high_gpa_students = df_students[df_students['GPA'] >= 3.5]
print("\nStudents with GPA >= 3.5:")
print(high_gpa_students)

# Sort students by GPA[cite: 2]
sorted_students = df_students.sort_values(by='GPA', ascending=False)
print("\nStudents sorted by GPA (descending):")
print(sorted_students)

# Find average GPA by major[cite: 2]
avg_gpa_by_major = df_students.groupby('major')['GPA'].mean()
print("\nAverage GPA by major:")
print(avg_gpa_by_major)

import pandas as pd

# Load both files[cite: 3]
students = pd.read_csv('students.csv')
scores = pd.read_csv('scores.csv')

# Check missing values[cite: 3]
print("Missing values in students dataset:")
print(students.isnull().sum())

print("\nMissing values in scores dataset:")
print(scores.isnull().sum())

# Fill or remove missing data appropriately[cite: 3]
# Drop rows where essential identifiers are missing
students_clean = students.dropna(subset=['student_id'])
scores_clean = scores.dropna(subset=['student_id'])

# Impute missing numeric scores with column mean
numeric_cols = scores_clean.select_dtypes(include=['number']).columns
scores_clean[numeric_cols] = scores_clean[numeric_cols].fillna(scores_clean[numeric_cols].mean())

# Merge the two datasets[cite: 3]
merged_df = pd.merge(students_clean, scores_clean, on='student_id', how='inner')

# Calculate each student's average score[cite: 3]
# Handle both wide format (multiple test columns) and long format (row per test score)
if 'score' in merged_df.columns:
    student_avg = merged_df.groupby(['student_id', 'name', 'major'])['score'].mean().reset_index()
    student_avg.rename(columns={'score': 'avg_score'}, inplace=True)
else:
    score_cols = [c for c in scores_clean.columns if c != 'student_id']
    merged_df['avg_score'] = merged_df[score_cols].mean(axis=1)
    student_avg = merged_df[['student_id', 'name', 'major', 'avg_score']].drop_duplicates()

print("\nEach student's average score:")
print(student_avg)

# Find the top 5 students[cite: 3]
top_5_students = student_avg.sort_values(by='avg_score', ascending=False).head(5)
print("\nTop 5 students:")
print(top_5_students)

# Compute average score by major[cite: 3]
avg_score_by_major = student_avg.groupby('major')['avg_score'].mean()
print("\nAverage score by major:")
print(avg_score_by_major)