list = list(map(int,input("Enter number in the list:").split()))
res = [num for num in list if num%2==0]
print(res)