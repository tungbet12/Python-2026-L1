num = int(input("Enter a number? "))
if num <=0:
    print(num," is not a perfect number")
else :
    divisor = 0 
    for i in range(1,num):
        if num % i ==0:
            divisor +=1
    if divisor == num:
        print(num," is not a perfect number")
    else:
        print(num,"is  a perfect number")