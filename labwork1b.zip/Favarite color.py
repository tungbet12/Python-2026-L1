corlor = ["Blue","red","yellow"]
fav = input("Input your favorite color:")
if fav in corlor:
    print("Your color at in" ,corlor.index(fav)+1,"in my list")
else:
    print("sorry, i could not find your favorite corlor")    
