s = str(input("Enter the price: "))
remove = "$"

for r in remove:
    s = s.replace(r,"")
print(s)