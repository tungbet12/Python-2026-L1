Celsius = float(input(" Enter the temperature in Celsius"))
Fahrenheit = (1.8 * Celsius ) + 32
print( " Temperature in Celsius =", Fahrenheit)