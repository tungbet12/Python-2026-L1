radius = float(input("Enter circle radius? "))
# call radius

area = 3.14 * radius ** 2 # caculus the area 
print("Circle area =", area) # print the circal area 
