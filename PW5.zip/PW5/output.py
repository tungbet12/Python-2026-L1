import curses


def show_students_and_gpa(stdscr, manager):
    stdscr.clear()
    manager.sort_students_by_gpa()
    stdscr.addstr(0, 0, "=== LIST STUDENT AND GPA (DOWN LIST) ===")
    row = 2
    stdscr.addstr(row, 0, f"{'ID':<10} | {'Name':<20} | {'DOB':<12} | {'GPA':<6}")
    stdscr.addstr(row + 1, 0, "-" * 55)
    row += 2

    for student in manager.get_students():
        stdscr.addstr(row, 0, f"{student.get_id():<10} | {student.get_name():<20} | {student.get_dob():<12} | {student.get_gpa():<6.2f}")
        row += 1

    stdscr.addstr(row + 2, 0, "Press any key to return...")
    stdscr.getch()