import curses
from domains import Student, Course


def get_input_str(stdscr, prompt, y, x=0):
    stdscr.addstr(y, x, prompt)
    stdscr.refresh()
    curses.echo()
    input_bytes = stdscr.getstr(y, x + len(prompt))
    curses.noecho()
    return input_bytes.decode('utf-8').strip()


def input_students(stdscr, manager):
    stdscr.clear()
    stdscr.addstr(0, 0, "=== INPUT STUDENT LIST ===")
    n = int(get_input_str(stdscr, "Enter number of students: ", 2))
    row = 4
    for i in range(n):
        stdscr.addstr(row, 0, f"--- Student {i + 1} ---")
        row += 1
        sid = get_input_str(stdscr, "Student ID: ", row)
        row += 1
        name = get_input_str(stdscr, "Student name: ", row)
        row += 1
        dob = get_input_str(stdscr, "Date of birth: ", row)
        row += 2
        manager.add_student(Student(sid, name, dob))

    # Save student information to students.txt after completing input
    with open("students.txt", "w", encoding="utf-8") as f:
        for student in manager.get_students():
            f.write(f"{student.get_id()},{student.get_name()},{student.get_dob()}\n") 

    stdscr.addstr(row, 0, "Saved students to students.txt! Press any key...")
    stdscr.getch()


def input_courses(stdscr, manager):
    stdscr.clear()
    stdscr.addstr(0, 0, "=== INPUT COURSE LIST ===")
    n = int(get_input_str(stdscr, "Enter number of courses: ", 2))
    row = 4
    for i in range(n):
        stdscr.addstr(row, 0, f"--- Course {i + 1} ---")
        row += 1
        cid = get_input_str(stdscr, "Course ID: ", row)
        row += 1
        name = get_input_str(stdscr, "Course name: ", row)
        row += 1
        credits = int(get_input_str(stdscr, "Number of credits: ", row))
        row += 2
        manager.add_course(Course(cid, name, credits))

    # Save course information to courses.txt after completing input
    with open("courses.txt", "w", encoding="utf-8") as f:
        for course in manager.get_courses():
            f.write(f"{course.get_id()},{course.get_name()},{course.get_credits()}\n")

    stdscr.addstr(row, 0, "Saved courses to courses.txt! Press any key...")
    stdscr.getch()


def input_marks(stdscr, manager):
    stdscr.clear()
    stdscr.addstr(0, 0, "=== INPUT MARKS ===")
    if not manager.get_courses() or not manager.get_students():
        stdscr.addstr(2, 0, "Please enter students and courses first! Press any key...")
        stdscr.getch()
        return

    row = 2
    for course in manager.get_courses():
        stdscr.addstr(row, 0, f"Course: {course.get_name()} ({course.get_id()})")
        row += 1
        for student in manager.get_students():
            raw_mark = float(get_input_str(stdscr, f" Mark for {student.get_name()}: ", row))
            manager.set_mark(course.get_id(), student.get_id(), raw_mark)
            row += 1
        row += 1

    # Save mark information to marks.txt after completing input
    with open("marks.txt", "w", encoding="utf-8") as f:
        for course in manager.get_courses():
            for student in manager.get_students():
                mark = manager.get_mark(course.get_id(), student.get_id())
                if mark is not None:
                    f.write(f"{course.get_id()},{student.get_id()},{mark}\n")

    stdscr.addstr(row, 0, "Saved marks to marks.txt! Press any key...")
    stdscr.getch()