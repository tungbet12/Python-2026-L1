import curses
import math
import os
import zipfile
import numpy as np

# 1. Imported domain models[cite: 1, 4]
from domains import Course, Student
from input import input_courses, input_marks, input_students
from output import show_students_and_gpa


class StudentMarkManagement:

  def __init__(self):
    self._students = []
    self._courses = []
    self._marks = {}

  def get_students(self):
    return self._students

  def get_courses(self):
    return self._courses

  def get_marks(self):
    return self._marks

  # 2. Added get_mark method for input.py[cite: 1, 4]
  def get_mark(self, course_id, student_id):
    return self._marks.get(course_id, {}).get(student_id, None)

  def add_student(self, student):
    self._students.append(student)

  def add_course(self, course):
    self._courses.append(course)

  def set_mark(self, course_id, student_id, mark):
    if course_id not in self._marks:
      self._marks[course_id] = {}
    # Round down to 1 decimal place using math.floor()[cite: 4]
    rounded_mark = math.floor(mark * 10) / 10.0
    self._marks[course_id][student_id] = rounded_mark

  def calculate_gpa(self, student_id):
    student_marks = []
    course_credits = []

    for course in self._courses:
      cid = course.get_id()
      if cid in self._marks and student_id in self._marks[cid]:
        student_marks.append(self._marks[cid][student_id])
        course_credits.append(course.get_credits())

    if not student_marks:
      return 0.0

    marks_arr = np.array(student_marks)
    credits_arr = np.array(course_credits)

    weighted_sum = np.sum(marks_arr * credits_arr)
    total_credits = np.sum(credits_arr)

    if total_credits == 0:
      return 0.0

    gpa = weighted_sum / total_credits
    return math.floor(gpa * 100) / 100.0

  def update_all_gpas(self):
    for student in self._students:
      gpa = self.calculate_gpa(student.get_id())
      student.set_gpa(gpa)

  def sort_students_by_gpa(self):
    self.update_all_gpas()
    self._students.sort(key=lambda s: s.get_gpa(), reverse=True)


# 3. Function to decompress archive and load saved data on launch[cite: 2, 4]
def load_data_on_startup(manager):
  if os.path.exists('students.dat'):
    with zipfile.ZipFile('students.dat', 'r') as zipf:
      zipf.extractall()

  if os.path.exists('students.txt'):
    with open('students.txt', 'r', encoding='utf-8') as f:
      for line in f:
        parts = line.strip().split(',')
        if len(parts) == 3:
          manager.add_student(Student(parts[0], parts[1], parts[2]))

  if os.path.exists('courses.txt'):
    with open('courses.txt', 'r', encoding='utf-8') as f:
      for line in f:
        parts = line.strip().split(',')
        if len(parts) == 3:
          manager.add_course(Course(parts[0], parts[1], int(parts[2])))

  if os.path.exists('marks.txt'):
    with open('marks.txt', 'r', encoding='utf-8') as f:
      for line in f:
        parts = line.strip().split(',')
        if len(parts) == 3:
          manager.set_mark(parts[0], parts[1], float(parts[2]))


# 4. Function to compress .txt files into students.dat before exiting[cite: 2, 4]
def compress_data_on_exit():
  files_to_pack = ['students.txt', 'courses.txt', 'marks.txt']
  with zipfile.ZipFile('students.dat', 'w', zipfile.ZIP_DEFLATED) as zipf:
    for file_name in files_to_pack:
      if os.path.exists(file_name):
        zipf.write(file_name)


def main(stdscr):
  manager = StudentMarkManagement()

  # Load any existing data on application start[cite: 2, 4]
  load_data_on_startup(manager)

  while True:
    stdscr.clear()
    stdscr.addstr(
        0,
        0,
        "================ STUDENT MARK MANAGEMENT (PW5) ================",
    )
    stdscr.addstr(2, 0, "1. Input student list")
    stdscr.addstr(3, 0, "2. Input course list")
    stdscr.addstr(4, 0, "3. Input marks")
    stdscr.addstr(5, 0, "4. View student list & GPA (Sorted)")
    stdscr.addstr(6, 0, "0. Exit")
    stdscr.addstr(8, 0, "Your choice: ")
    stdscr.refresh()

    choice = stdscr.getkey()
    if choice == "1":
      input_students(stdscr, manager)
    elif choice == "2":
      input_courses(stdscr, manager)
    elif choice == "3":
      input_marks(stdscr, manager)
    elif choice == "4":
      show_students_and_gpa(stdscr, manager)
    elif choice == "0":
      compress_data_on_exit()  # Save data to students.dat[cite: 2, 4]
      break


if __name__ == "__main__":
  curses.wrapper(main)