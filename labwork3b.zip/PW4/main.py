import curses
import math
import numpy as np

from input import input_students, input_courses, input_marks
from output import show_students_and_gpa


class StudentMarkManagement:
    def __init__(self):
        self._students = []
        self._courses = []
        self._marks = {}

    def get_students(self):
        return self._students

    def get_courses(self):
        return self._courses

    def get_marks(self):
        return self._marks

    def add_student(self, student):
        self._students.append(student)

    def add_course(self, course):
        self._courses.append(course)

    def set_mark(self, course_id, student_id, mark):
        if course_id not in self._marks:
            self._marks[course_id] = {}
        # Làm tròn xuống 1 chữ số thập phân bằng math.floor()
        rounded_mark = math.floor(mark * 10) / 10.0
        self._marks[course_id][student_id] = rounded_mark

    def calculate_gpa(self, student_id):
        student_marks = []
        course_credits = []

        for course in self._courses:
            cid = course.get_id()
            if cid in self._marks and student_id in self._marks[cid]:
                student_marks.append(self._marks[cid][student_id])
                course_credits.append(course.get_credits())

        if not student_marks:
            return 0.0

        marks_arr = np.array(student_marks)
        credits_arr = np.array(course_credits)

        weighted_sum = np.sum(marks_arr * credits_arr)
        total_credits = np.sum(credits_arr)

        if total_credits == 0:
            return 0.0

        gpa = weighted_sum / total_credits
        return math.floor(gpa * 100) / 100.0

    def update_all_gpas(self):
        for student in self._students:
            gpa = self.calculate_gpa(student.get_id())
            student.set_gpa(gpa)

    def sort_students_by_gpa(self):
        self.update_all_gpas()
        self._students.sort(key=lambda s: s.get_gpa(), reverse=True)


def main(stdscr):
    manager = StudentMarkManagement()
    while True:
        stdscr.clear()
        stdscr.addstr(0, 0, "================ QUẢN LÝ ĐIỂM SINH VIÊN (PW4) ================")
        stdscr.addstr(2, 0, "1. Nhập danh sách sinh viên")
        stdscr.addstr(3, 0, "2. Nhập danh sách môn học")
        stdscr.addstr(4, 0, "3. Nhập điểm số")
        stdscr.addstr(5, 0, "4. Xem danh sách sinh viên & GPA (Đã sắp xếp)")
        stdscr.addstr(6, 0, "0. Thoát")
        stdscr.addstr(8, 0, "Lựa chọn của bạn: ")
        stdscr.refresh()

        choice = stdscr.getkey()
        if choice == '1':
            input_students(stdscr, manager)
        elif choice == '2':
            input_courses(stdscr, manager)
        elif choice == '3':
            input_marks(stdscr, manager)
        elif choice == '4':
            show_students_and_gpa(stdscr, manager)
        elif choice == '0':
            break


if __name__ == "__main__":
    curses.wrapper(main)