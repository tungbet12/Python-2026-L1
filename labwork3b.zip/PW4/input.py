import curses
from domains import Student, Course


def get_input_str(stdscr, prompt, y, x=0):
    stdscr.addstr(y, x, prompt)
    stdscr.refresh()
    curses.echo()
    input_bytes = stdscr.getstr(y, x + len(prompt))
    curses.noecho()
    return input_bytes.decode('utf-8').strip()


def input_students(stdscr, manager):
    stdscr.clear()
    stdscr.addstr(0, 0, "=== NHẬP DANH SÁCH SINH VIÊN ===")
    n = int(get_input_str(stdscr, "Nhập số lượng sinh viên: ", 2))
    row = 4
    for i in range(n):
        stdscr.addstr(row, 0, f"--- Sinh viên {i + 1} ---")
        row += 1
        sid = get_input_str(stdscr, "ID sinh viên: ", row)
        row += 1
        name = get_input_str(stdscr, "Tên sinh viên: ", row)
        row += 1
        dob = get_input_str(stdscr, "Ngày sinh: ", row)
        row += 2
        manager.add_student(Student(sid, name, dob))
    stdscr.addstr(row, 0, "Đã lưu sinh viên! Nhấn phím bất kỳ...")
    stdscr.getch()


def input_courses(stdscr, manager):
    stdscr.clear()
    stdscr.addstr(0, 0, "=== NHẬP DANH SÁCH MÔN HỌC ===")
    n = int(get_input_str(stdscr, "Nhập số lượng môn học: ", 2))
    row = 4
    for i in range(n):
        stdscr.addstr(row, 0, f"--- Môn học {i + 1} ---")
        row += 1
        cid = get_input_str(stdscr, "Mã môn học: ", row)
        row += 1
        name = get_input_str(stdscr, "Tên môn học: ", row)
        row += 1
        credits = int(get_input_str(stdscr, "Số tín chỉ: ", row))
        row += 2
        manager.add_course(Course(cid, name, credits))
    stdscr.addstr(row, 0, "Đã lưu môn học! Nhấn phím bất kỳ...")
    stdscr.getch()


def input_marks(stdscr, manager):
    stdscr.clear()
    stdscr.addstr(0, 0, "=== NHẬP ĐIỂM SỐ ===")
    if not manager.get_courses() or not manager.get_students():
        stdscr.addstr(2, 0, "Cần nhập sinh viên và môn học trước! Nhấn phím bất kỳ...")
        stdscr.getch()
        return

    row = 2
    for course in manager.get_courses():
        stdscr.addstr(row, 0, f"Môn học: {course.get_name()} ({course.get_id()})")
        row += 1
        for student in manager.get_students():
            raw_mark = float(get_input_str(stdscr, f" Điểm cho {student.get_name()}: ", row))
            manager.set_mark(course.get_id(), student.get_id(), raw_mark)
            row += 1
        row += 1

    stdscr.addstr(row, 0, "Đã lưu điểm! Nhấn phím bất kỳ...")
    stdscr.getch()